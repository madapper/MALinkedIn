//
//  ViewController.m
//  TestLoginWithLinkedIn
//
//  Created by Paul Napier on 11/10/13.
//  Copyright (c) 2013 MadApper. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
//    [MALinkedInSession clearSharedSession];
    MALinkedInSession *session = [MALinkedInSession cachedSession];
//    NSLog(@"%@",session.token);
    if (!session.token) {
        MALinkedInLogInView *login = [[MALinkedInLogInView alloc]initWithRedirectURL:@"http://www.madapper.co.uk" clientID:@"chj4mdcmn3v4" clientSecret:@"R8Gh4XahC03yQ3ls"];
        login.delegate = self;
        [self.view addSubview:login];
    }else{
        [self linkedInViewDidLogIn:session];
    }

}



-(void)linkedInViewDidLogIn:(MALinkedInSession *)session{
    
    //////////////////////////////////////////////
    //////////People - Profile////////////////////
    //////////////////////////////////////////////

//    MALinkedInPeopleProfileFields *fields = [MALinkedInPeopleProfileFields new];
//    fields.field_r_basicprofile_id = true;
//    fields.field_r_basicprofile_last_name = true;
//    fields.field_r_fullprofile_date_of_birth = true;
//    fields.field_r_fullprofile_languages = true;
//    fields.field_r_fullprofile_interests = true;
//
//    // Request Me Standard
//    [MALinkedInPeopleProfile requestMe:session completion:^(NSObject *object) {
//        NSLog(@"%@",object);
//    }];
    
    
//    // Request Me with components
//    [MALinkedInPeopleProfile requestMe:session components:fields completion:^(NSObject *object) {
//        NSLog(@"%@",object);
//    }];
    
//    // Request Person by ID
//    [MALinkedInPeopleProfile requestPersonByID:@"6Dto1AcIzw" session:session completion:^(NSObject *object) {
//        NSLog(@"%@",object);
//    }];

//    // Request Person by ID with components
//    [MALinkedInPeopleProfile requestPersonByID:@"6Dto1AcIzw" session:session components:fields completion:^(NSObject *object) {
//        NSLog(@"%@",object);
//    }];
    
//    // Request Person by URL
//    [MALinkedInPeopleProfile requestPersonByURL:@"http://www.linkedin.com/in/paulnapier" session:session completion:^(NSObject *object) {
//        NSLog(@"%@",object);
//    }];
    
//    // Request Person by URL with components
//    [MALinkedInPeopleProfile requestPersonByURL:@"http://www.linkedin.com/in/paulnapier" session:session components:fields completion:^(NSObject *object) {
//        NSLog(@"%@",object);
//    }];
    
    
    //////////////////////////////////////////////
    //////////People - Connections////////////////
    //////////////////////////////////////////////
    
    
//    MALinkedInPeopleConnectionsFields *fields = [MALinkedInPeopleConnectionsFields new];
//    fields.field_r_basicprofile_id = true;
//    fields.field_r_basicprofile_last_name = true;
    
//    // Request Connections from me
//    [MALinkedInPeopleConnections requestMyConnections:session completion:^(NSObject *object) {
//        NSLog(@"%@",object);
//    }];
    
//    // Request Connections from me with components
//    [MALinkedInPeopleConnections requestMyConnections:session components:fields completion:^(NSObject *object) {
//        NSLog(@"%@",object);
//    }];
    
//    // Request Connections from person with ID
//    [MALinkedInPeopleConnections requestConnectionsForPersonByID:@"6Dto1AcIzw" session:session completion:^(NSObject *object) {
//        NSLog(@"%@",object);
//    }];
    
//    // Request Connections from person with ID with components
//    [MALinkedInPeopleConnections requestConnectionsForPersonByID:@"6Dto1AcIzw" session:session components:fields completion:^(NSObject *object) {
//        NSLog(@"%@",object);
//    }];
    
//    // Request Connections from person with URL
//    [MALinkedInPeopleConnections requestConnectionsForPersonByURL:@"http://www.linkedin.com/in/paulnapier" session:session completion:^(NSObject *object) {
//        NSLog(@"%@",object);
//    }];
    
//    // Request Connections from person with URL with components
//    [MALinkedInPeopleConnections requestConnectionsForPersonByURL:@"http://www.linkedin.com/in/paulnapier" session:session components:fields completion:^(NSObject *object) {
//        NSLog(@"%@",object);
//    }];
    
//    // Request new and/or modified connections for me
//    [MALinkedInPeopleConnections requestConnections:session new:true modifiedSince:[NSDate  dateWithTimeIntervalSinceReferenceDate:403487000000] completion:^(NSObject *object) {
//        NSLog(@"%@",object);
//    }];
    
    
    //////////////////////////////////////////////
    //////////People - Search/////////////////////
    //////////////////////////////////////////////
    
//    // Search Test
//    [MALinkedInPeopleSearch search:session keyWords:@"We Are Social" start:0 completion:^(NSObject *object) {
//        NSLog(@"%@",object);
//    }];

//    // Search Facets test
//    
//    MALinkedInPeopleSearchBucket *bucket = [MALinkedInPeopleSearchBucket new];
//    bucket.bucket_code = true;
//    bucket.bucket_count = true;
//    bucket.bucket_name = true;
//    
//    MALinkedInPeopleSearchFacets *facets = [MALinkedInPeopleSearchFacets new];
//    facets.facet_name = true;
//    facets.facet_bucket = bucket;
//    
//    MALinkedInPeopleSearchFields *fields = [MALinkedInPeopleSearchFields new];
//    fields.field_network = MALinkedInPeopleSearchFieldsNetworkFirst;
//    
//    [MALinkedInPeopleSearch searchFacets:session facets:facets fields:fields completion:^(NSObject *object) {
//        NSLog(@"%@",object);
//    }];
    
    
    //////////////////////////////////////////////
    /////////////////Companies////////////////////
    //////////////////////////////////////////////
    
//    // Request Company
//    
//    [MALinkedInCompanies requestCompany:session withUniversalName:@"linkedin" completion:^(NSObject *object) {
//        NSLog(@"%@",object);
//    }];
    
//    // Request Company with Fields
//    MALinkedInCompaniesFields *fields = [MALinkedInCompaniesFields new];
//    fields.field_name = true;
//    fields.field_logo_url = true;
//    
//    [MALinkedInCompanies requestCompany:session fields:fields withUniversalName:@"linkedin" completion:^(NSObject *object) {
//        NSLog(@"%@",object);
//    }];
    
    
    //////////////////////////////////////////////
    //////////Social - Network////////////////////
    //////////////////////////////////////////////
    
//    MALinkedInSocialNetworkFields *fields = [MALinkedInSocialNetworkFields new];
//    fields.field_type = @[@(MALinkedInSocialNetworkFieldsTypeCMPY)];
//    fields.field_count = 10;
    
    
//    // Request Network Updates
//    [MALinkedInSocialNetwork requestMyUpdates:session completion:^(NSObject *object) {
//        NSLog(@"%@",object);
//    }];
    
//    // Request Network Updates with Fields
//    [MALinkedInSocialNetwork requestUpdates:session fields:fields completion:^(NSObject *object) {
//        NSLog(@"%@",object);
//    }];
    
    
//    // Request Network Stats
//    [MALinkedInSocialNetwork requestNetworkStats:session completion:^(NSObject *object) {
//        NSLog(@"%@",object);
//    }];

    
    //////////////////////////////////////////////
    //////////////Groups//////////////////////////
    //////////////////////////////////////////////
    
    
//    MALinkedInGroupsFields *fields = [MALinkedInGroupsFields new];
//    fields.group_id = true;
//    fields.group_location_country = true;
//    fields.group_location_postal_code = true;
//    fields.group_name = true;
//    fields.group_num_members = true;
//    fields.group_posts = 3;
//    fields.post_id = true;
//    fields.post_likes = true;
//    fields.post_comments = 3;
//    fields.comment_id = true;
//    
//    MALinkedInGroupsParameters *params = [MALinkedInGroupsParameters new];
//    params.params_order = MALinkedInGroupsParametersOrderRecency;

    
//    // Request my Group Memberships
//    [MALinkedInGroups requestMyGroups:session start:0 count:100 completion:^(NSObject *object) {
//        NSLog(@"%@",object);
//    }];
    
//    // Request my Groups with fields
//    [MALinkedInGroups requestMyGroups:session start:0 count:15 fields:fields completion:^(NSObject *object) {
//        NSLog(@"%@",object);
//    }];
    
//    // Request Group
//    [MALinkedInGroups requestGroup:session groupID:@"52009" fields:fields parameters:params completion:^(NSObject *object) {
//        NSLog(@"%@",object);
//    }];
    
//    //Request Post
//    [MALinkedInGroups requestPost:session postID:@"g-54395-S-5797371693756334081" fields:fields completion:^(NSObject *object) {
//        NSLog(@"%@",object);
//    }];

//    // Request Comment
//    [MALinkedInGroups requestComment:session commentID:@"g-54395-S-5797371693756334081-5797732400825905152" fields:fields completion:^(NSObject *object) {
//        NSLog(@"%@",object);
//    }];
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
