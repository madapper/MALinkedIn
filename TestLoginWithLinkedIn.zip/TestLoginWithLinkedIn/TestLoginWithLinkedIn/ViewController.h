//
//  ViewController.h
//  TestLoginWithLinkedIn
//
//  Created by Paul Napier on 11/10/13.
//  Copyright (c) 2013 MadApper. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MALinkedIn/MALinkedIn.h>

@interface ViewController : UIViewController<MALinkedInViewDelegate>

@end
