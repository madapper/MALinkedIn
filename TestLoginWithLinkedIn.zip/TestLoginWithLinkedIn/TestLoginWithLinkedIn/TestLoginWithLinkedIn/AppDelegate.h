//
//  AppDelegate.h
//  TestLoginWithLinkedIn
//
//  Created by Paul Napier on 11/10/13.
//  Copyright (c) 2013 MadApper. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
